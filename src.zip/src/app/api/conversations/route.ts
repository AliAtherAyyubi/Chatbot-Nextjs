import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const conversations = await prisma.conversation.findMany({
      orderBy: { updatedAt: "desc" },
      include: {
        messages: {
          orderBy: { createdAt: "asc" },
        },
      },
    });
    return NextResponse.json(conversations);
  } catch (error) {
    console.error("GET /api/conversations error:", error);
    return NextResponse.json(
      { error: String(error) },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    console.log("Creating conversation with title:", body.title);

    const conversation = await prisma.conversation.create({
      data: { title: body.title },
      include: { messages: true },
    });

    console.log("Created conversation:", conversation.id);
    return NextResponse.json(conversation);
  } catch (error) {
    console.error("POST /api/conversations error:", error);
    return NextResponse.json(
      { error: String(error) },
      { status: 500 }
    );
  }
}