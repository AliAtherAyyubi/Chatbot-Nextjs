import "server-only"; 
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// GET — fetch all messages for a conversation
export async function GET(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const messages = await prisma.message.findMany({
      where: { conversationId: params.id },
      orderBy: { createdAt: "asc" },
    });
    return NextResponse.json(messages);
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch messages" }, { status: 500 });
  }
}

// POST — save a new message to a conversation
export async function POST(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { role, content } = await req.json();

    const message = await prisma.message.create({
      data: {
        role,
        content,
        conversationId: params.id,
      },
    });

    // bump updatedAt on conversation so it sorts to top
    await prisma.conversation.update({
      where: { id: params.id },
      data: { updatedAt: new Date() },
    });

    return NextResponse.json(message);
  } catch (error) {
    return NextResponse.json({ error: "Failed to save message" }, { status: 500 });
  }
}